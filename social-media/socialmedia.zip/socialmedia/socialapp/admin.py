from django.contrib import admin
from .models import Post,User_Detail,PostLike

admin.site.register(Post)
admin.site.register(User_Detail)
admin.site.register(PostLike)

